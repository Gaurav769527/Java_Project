package Java_Project_Programs;

import java.util.Scanner;

public class Even_Odd_04 {

	public static void main(String[] args) {



		int num;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a number to check Odd or Even:");
		num=s.nextInt();
		if(num % 2== 0)
		{
			System.out.println("The given number "+num+" is Even:");
		}
		else
		{
			System.out.println("The given number "+num+" is Odd:");
		}

		s.close();
	}

}
