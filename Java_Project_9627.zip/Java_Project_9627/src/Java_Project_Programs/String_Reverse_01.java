package Java_Project_Programs;

public class String_Reverse_01 {

	public static void main(String[] args) {

		String originalStr = "I am a Learner";
		String reversedStr = "";

		for (int i = 0; i < originalStr.length(); i++) {
			reversedStr = originalStr.charAt(i) + reversedStr;
		}

		System.out.println("Reversed string: "+ reversedStr);

	}

}


