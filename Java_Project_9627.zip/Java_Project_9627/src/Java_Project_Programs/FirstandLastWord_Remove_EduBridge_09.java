package Java_Project_Programs;

public class FirstandLastWord_Remove_EduBridge_09 {

		 
		    public static String
		    removeFirstandLast(String str)
		    {
		 
		        str = str.substring(1, str.length() - 1);
		 
		        return str;
		    }
		 
		    
		    public static void main(String args[])
		    {
		        
		        String str = "EduBridge";
		 
		        
		        System.out.print(removeFirstandLast(str));

	}

}
