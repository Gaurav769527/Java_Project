package Java_Project_Programs;

import java.util.Scanner;

public class Prime_Number_05 {

	public static void main(String[] args) {


		int num;
		Scanner s=new Scanner (System.in);

		System.out.println("Enter the number to check Prime or Not:");
		num=s.nextInt();

		for(int i=2; i<= num/2; i++)

			if (num % i==0)
			{
				System.out.println("Number is  Prime:");
				break;
			}
			else
			{

				System.out.println("Number is  not Prime:");
				break;
			}

		s.close();

	}

}
