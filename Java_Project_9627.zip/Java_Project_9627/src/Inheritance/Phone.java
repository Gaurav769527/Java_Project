package Inheritance;

//Hybrid Inheritance--

class Keypad_Mobile extends Phone
{
	public void Single_Sim()
	{
		System.out.println("Wireless Keypad Mobile");
	}
}

class Smart_Phone extends Keypad_Mobile
{

	public void Dual_Sim_with_ScreenTouch()
	{
		System.out.println("DualSim_SmartPhone");
	}

}

class Tablet extends Keypad_Mobile
{
	public void Dual_Sim_with_AdvanceFeatures() 
	{
		System.out.println("Mini Laptop");
	}


}

public class Phone {

	public void Landline()
	{
		System.out.println("LAN Wire Intercome");
	}


	public static void main(String[] args) {

		Smart_Phone a=new Smart_Phone();
		a.Landline();
		a.Single_Sim();
		a.Dual_Sim_with_ScreenTouch();

		Tablet s1=new Tablet();
		s1.Landline();
		s1.Single_Sim();
		s1.Dual_Sim_with_AdvanceFeatures();

	}







}


