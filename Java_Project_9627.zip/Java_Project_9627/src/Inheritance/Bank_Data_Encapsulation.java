package Inheritance;

class Admin
{
	private String Name,Email;
	private long AccNo;
	private float Bal;


	public String getName()
	{

		return Name;
	}

	public void setName (String name1)
	{
		this.Name=name1;
	}
	public String getEmail()
	{

		return Email;
	}

	public void setEmail (String email1)
	{
		this.Email=email1;
	}
	public long getAccNo()
	{

		return AccNo;
	}

	public void setAccNo (long accno1)
	{
		this.AccNo=accno1;
	}
	public float getBal()
	{

		return Bal;
	}

	public void setBal (float bal1)
	{
		this.Bal=bal1;
	}


}
public class Bank_Data_Encapsulation {

	public static void main(String[] args) {

		Admin a=new Admin();
		System.out.println("New Account Open");

		a.setName("GAURAV");
		a.setEmail("gaurav00.yahoo.com");
		a.setAccNo(101010101010l);
		a.setBal(1234);

		System.out.println("\n Customer Name: " +a.getName()+ "\n EmailId: "+ a.getEmail()+ "\n AccountNumber: "+ a.getAccNo() + "\n Balance: " + a.getBal());


		a.setName("GAURAV1");
		a.setEmail("gaurav0012.yahoo.com");
		a.setAccNo(111010101011l);
		a.setBal(4321);

		System.out.println("\n Customer Name: " +a.getName() + "\n EmailId: "+ a.getEmail() + "\n AccountNumber: " + a.getAccNo() + "\n Balance: " + a.getBal());

	}

}
