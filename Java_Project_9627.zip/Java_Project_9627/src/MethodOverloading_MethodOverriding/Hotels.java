package MethodOverloading_MethodOverriding;

//Method Overriding--

class Moon extends Hotels
{  
	int getRoomRent()
	{
		return 350;
	}  
}  

class Taj extends Hotels
{  
	int getRoomRent()
	{
		return 4500;
	}  
}  
class Sun extends Hotels
{  
	int getRoomRent()
	{
		return 2500;
	}  
}
public class Hotels {


	int getRoomRent()
	{
		return 0;
	}  

	public static void main(String args[])
	{  
		Moon s=new Moon(); 

		Taj i=new Taj(); 

		Sun a=new Sun();  

		System.out.println("Moon Room Rent: "+s.getRoomRent()); 

		System.out.println("Taj Room Rent: "+i.getRoomRent());  

		System.out.println("Sun Room Rent: "+a.getRoomRent());


	}

}
