package MethodOverloading_MethodOverriding;

	//Method OverLoading--

class Room_Service {



	private String ID (int value)
	{
		return String.format("%d", value);
	}

	private String Salary (double value)
	{
		return String.format("%.3f", value);
	}

	private String Bonus (String value)
	{
		return String.format("%.2f", Double.parseDouble(value));
	}


	public static void main(String[] args) {

		Room_Service rs = new Room_Service();

		System.out.println(rs.ID(420));
		System.out.println(rs.Salary(89.9934));
		System.out.println(rs.Bonus("5500"));





	}

}



