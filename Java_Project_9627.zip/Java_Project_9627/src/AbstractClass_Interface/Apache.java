package AbstractClass_Interface;

interface TVS {

	void RacingBikes ();

	void Scooty();
}

public class Apache implements TVS {

	public void RacingBikes()
	{
		System.out.println("Pickup and Engine Perfomance is Awesome");
	}

	public void Scooty()
	{
		System.out.println("Have a Good Average and Good look");
	}

	public static void main(String[] args) {

		Apache myBike= new Apache();
		myBike.RacingBikes();
		myBike.Scooty();

	}
}